package com.rabbitmq.priorityproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriorityproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
