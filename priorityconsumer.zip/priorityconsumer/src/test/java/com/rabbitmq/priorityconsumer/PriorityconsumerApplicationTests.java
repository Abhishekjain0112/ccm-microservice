package com.rabbitmq.priorityconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriorityconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
