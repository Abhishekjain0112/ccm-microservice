package com.rabbitmq.priorityconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PriorityconsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PriorityconsumerApplication.class, args);
	}

}
