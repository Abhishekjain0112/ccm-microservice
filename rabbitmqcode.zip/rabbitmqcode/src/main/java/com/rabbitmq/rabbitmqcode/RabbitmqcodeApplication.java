package com.rabbitmq.rabbitmqcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqcodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitmqcodeApplication.class, args);
	}

}
