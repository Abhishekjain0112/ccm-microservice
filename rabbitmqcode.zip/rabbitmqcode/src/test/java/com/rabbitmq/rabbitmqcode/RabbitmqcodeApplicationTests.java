package com.rabbitmq.rabbitmqcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
